# FDS Conscious Reportability v1.1

This package contains the LaTeX manuscript, figures, generated data tables, and Python code for:

**Active Cognitive Pruning Controls Conscious Reportability in Finite Distinction Systems: A Variational, Network-Topological, and Thermodynamic Model**

## Contents

```text
FDS_Consciousness_Reportability_v1_1.tex   LaTeX source
FDS_Consciousness_Reportability_v1_1.pdf   compiled PDF
src/generate_figures.py                    figure and data generation script
figures/                                   PDF and PNG figures
data/                                      CSV data tables and parameter table
```

## Dependencies

- Python 3
- numpy
- matplotlib
- LaTeX distribution with revtex4-2

## Reproduce figures

```bash
python src/generate_figures.py
```

The script regenerates all figures and CSV data tables with fixed random seeds.

## Manuscript model additions in v1.1

- Constrained variational derivation of the load-pruning-access equations.
- Representational residue defined as unresolved variational free energy / KL load under capacity constraints.
- Network-topological access transition with a mean-field saddle-node projection.
- Leading covariance eigenmode as the high-dimensional early-warning statistic.
- Information-energy bridge using the Landauer lower bound.
- Experimental proxy map and threshold extraction protocol.

## Citation

Wu, Y. (2026). *Active Cognitive Pruning Controls Conscious Reportability in Finite Distinction Systems: A Variational, Network-Topological, and Thermodynamic Model*. Draft manuscript.
