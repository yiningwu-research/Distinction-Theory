import os
from collections import deque
import numpy as np
import matplotlib.pyplot as plt

OUT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
FIG = os.path.join(OUT, 'figures')
DATA = os.path.join(OUT, 'data')
os.makedirs(FIG, exist_ok=True)
os.makedirs(DATA, exist_ok=True)

rng = np.random.default_rng(42)

def savefig(name):
    for ext in ['pdf','png']:
        plt.savefig(os.path.join(FIG, f'{name}.{ext}'), bbox_inches='tight', dpi=200)
    plt.close()

def savecsv(name, arr, header):
    np.savetxt(os.path.join(DATA, f'{name}.csv'), arr, delimiter=',', header=header, comments='')

# Figure 1: loop diagram
fig, ax = plt.subplots(figsize=(9.5, 5.2)) # 稍微加高一点画布，给底部留出完整的弧线空间
ax.axis('off')

boxes = {
    'Task distinction demand\n$R_{\\min}^{(\\tau)}$': (0.15, 0.75),
    'Representational\nresidue $\\rho$': (0.50, 0.75),
    'Access network\n$G$': (0.85, 0.75),
    'Reportability\n$\\mathcal{R}$': (0.85, 0.25),
    'Active cognitive\npruning $S$': (0.50, 0.25),
    'Causal loop\n$A$': (0.15, 0.25),
}

ax.set_xlim(0, 1)
ax.set_ylim(0, 1)

for text, (x, y) in boxes.items():
    ax.text(x, y, text, ha='center', va='center', fontsize=12,
            bbox=dict(boxstyle='round,pad=0.45', fc='white', ec='black', lw=1.4))

def arrow(a, b, rad=0.0, label=None, text_offset=(0, 0)):
    ax.annotate('', xy=b, xytext=a, 
                arrowprops=dict(arrowstyle='->', lw=1.8, connectionstyle=f'arc3,rad={rad}'))
    if label:
        mx = (a[0] + b[0]) / 2 + text_offset[0]
        my = (a[1] + b[1]) / 2 + text_offset[1]
        ax.text(mx, my, label, fontsize=10, ha='center', va='center',
                bbox=dict(boxstyle='square,pad=0.15', fc='white', ec='none'))

arrow((0.26, 0.75), (0.39, 0.75), label='deposits')
arrow((0.61, 0.75), (0.74, 0.75), label='impairs')

arrow((0.85, 0.66), (0.85, 0.34), label='enables', text_offset=(0.06, 0))
arrow((0.50, 0.34), (0.50, 0.66), label='reduces', text_offset=(-0.06, 0))
arrow((0.15, 0.34), (0.15, 0.66), label='sampling', text_offset=(-0.07, 0))

arrow((0.26, 0.25), (0.39, 0.25), label='feedback')
arrow((0.74, 0.25), (0.61, 0.25), label='clears')

arrow((0.85, 0.18), (0.15, 0.18), rad=-0.45, label='action / report', text_offset=(0, -0.15))

ax.set_title('Finite-distinction maintenance loop for conscious reportability', fontsize=15, pad=12)
savefig('fig1_loop')

# Figure 2: network percolation under residue/pruning ratio
N=90
base = rng.random((N,N))
base = np.triu(base,1)
base += base.T
ratios = np.linspace(0,4.0,80)
giant=[]; lam1=[]; covlead=[]
for u in ratios:
    p_edge = 1/(1+np.exp(2.2*(u-1.7)))
    A = (base < p_edge).astype(float)
    np.fill_diagonal(A,0)
    # giant component size
    seen=np.zeros(N,dtype=bool); best=0
    for i in range(N):
        if not seen[i]:
            q=deque([i]); seen[i]=True; size=0
            while q:
                v=q.popleft(); size+=1
                for w in np.where(A[v]>0)[0]:
                    if not seen[w]: seen[w]=True; q.append(w)
            best=max(best,size)
    giant.append(best/N)
    eig=np.linalg.eigvalsh(A)
    lam1.append(eig[-1]/N)
    # leading covariance under linear relaxation dx=-k x + noise, k ~ distance from threshold
    dist=np.abs(u-1.7)+0.03
    covlead.append(1/dist)
arr=np.c_[ratios, giant, lam1, covlead]
savecsv('network_topology_sweep', arr, 'load_pruning_ratio,giant_component_fraction,normalized_leading_eigenvalue,leading_covariance_proxy')
fig, ax1 = plt.subplots(figsize=(6.4,4.6))
ax1.plot(ratios, giant, label='giant access component')
ax1.plot(ratios, lam1, label='normalized leading eigenvalue')
ax1.axvline(1.7,ls='--',lw=1,label='network access threshold')
ax1.set_xlabel('residue / pruning ratio $\\rho/(S+\\epsilon)$')
ax1.set_ylabel('global access proxy')
ax1.legend(loc='upper right', fontsize=9)
ax2=ax1.twinx()
ax2.plot(ratios, covlead, ls=':', label='leading covariance proxy')
ax2.set_ylabel('early-warning covariance proxy')
ax1.set_title('Network access transition under residue accumulation')
savefig('fig2_network_transition')

# Figure 3: nonmonotonic reportability window
psi=np.linspace(0,1,400)
R=1/(1+np.exp(-20*(psi-0.18))) * 1/(1+np.exp(20*(psi-0.78)))
Iself=R*(0.6+0.8*np.exp(-((psi-0.48)/0.22)**2))
rigid=1/(1+np.exp(-20*(psi-0.78)))
arr=np.c_[psi,R,Iself,rigid]
savecsv('reportability_window', arr, 'Psi,reportability_proxy,self_model_proxy,rigidification_proxy')
fig, ax=plt.subplots(figsize=(6.4,4.3))
ax.plot(psi,R,label='reportability $R$')
ax.plot(psi,Iself,label='dynamic self-model proxy')
ax.plot(psi,rigid,ls='--',label='rigidification / overload')
ax.axvspan(0.18,0.78,alpha=0.12,label='maintained window')
ax.set_xlabel('order parameter $\\Psi=\\tanh(\\alpha\\rho/(S+\\epsilon))$')
ax.set_ylabel('normalized proxy')
ax.set_title('Non-monotonic access window')
ax.legend(fontsize=9)
savefig('fig3_reportability_window')

# Figure 4: early warning with covariance eigenvalue and autocorrelation
r=np.logspace(-2,0,80)
tau=1/(2*np.sqrt(r)); var=0.05**2/(4*np.sqrt(r)); ac=np.exp(-1/tau)
arr=np.c_[r,tau,var,ac]
savecsv('early_warning_scaling', arr, 'distance_to_fold_r,recovery_time,variance,lag1_autocorrelation')
fig, ax1=plt.subplots(figsize=(6.4,4.4))
ax1.loglog(r,tau,label='recovery time')
ax1.loglog(r,var/var.max()*tau.max(),ls='--',label='scaled variance')
ax1.invert_xaxis(); ax1.set_xlabel('distance to access fold $r$'); ax1.set_ylabel('early-warning magnitude')
ax2=ax1.twinx(); ax2.semilogx(r,ac,ls=':',label='lag-1 autocorrelation')
ax2.set_ylabel('lag-1 autocorrelation')
ax1.set_title('Early-warning scaling near access loss')
lines,labels=ax1.get_legend_handles_labels(); lines2,labels2=ax2.get_legend_handles_labels(); ax1.legend(lines+lines2,labels+labels2,fontsize=9,loc='lower left')
savefig('fig4_early_warning')

# Figure 5: anesthesia emergence ordering model
t=np.linspace(-5,25,400)
def logistic(t,t0,k): return 1/(1+np.exp(-k*(t-t0)))
A=logistic(t,0,1.0)
Sosc=0.15+0.55*logistic(t,4,0.9)*(1-0.25*np.exp(-0.08*(t-4).clip(min=0))*np.cos(2*np.pi*(t-4)/5))
G=logistic(t,9,0.65)
I=logistic(t,14,0.55)*G
arr=np.c_[t,A,Sosc,G,I]
savecsv('recovery_ordering', arr, 'time,causal_responsiveness_A,pruning_inhibitory_recovery_S,global_access_G,self_model_coherence')
fig, ax=plt.subplots(figsize=(6.5,4.2))
ax.plot(t,A,label='causal responsiveness $A$')
ax.plot(t,Sosc,label='pruning / inhibitory rhythm proxy')
ax.plot(t,G,label='global access $G$')
ax.plot(t,I,label='self-model coherence')
ax.set_xlabel('time relative to first responsiveness')
ax.set_ylabel('normalized recovery proxy')
ax.set_title('Predicted partial order during anesthesia emergence')
ax.legend(fontsize=8,loc='lower right')
savefig('fig5_recovery_ordering')

# Figure 6: rescue window
T=np.linspace(0,28,90); Sval=np.linspace(0.02,0.5,90); TT,SS=np.meshgrid(T,Sval)
required_line=0.08+0.006*T+0.00035*T**2
required=0.08+0.006*TT+0.00035*TT**2
Prescue=1/(1+np.exp(-40*(SS-required)))
arr=np.c_[TT.ravel(),SS.ravel(),Prescue.ravel(),required.ravel()]
savecsv('rescue_window',arr,'delay,restored_pruning,rescue_probability,required_pruning')
fig,ax=plt.subplots(figsize=(6.2,4.3))
im=ax.imshow(Prescue,origin='lower',extent=[T.min(),T.max(),Sval.min(),Sval.max()],aspect='auto')
ax.plot(T,required_line,ls='--',lw=2,label='50% rescue boundary')
ax.set_xlabel('delay after pruning interruption')
ax.set_ylabel('restored pruning $S_{rescue}$')
ax.set_title('Rescue-window closure')
ax.legend(fontsize=9)
fig.colorbar(im,ax=ax,label='rescue probability')
savefig('fig6_rescue_window')

# Figure 7: phase diagram over load and pruning
load=np.linspace(0.1,1.5,120); prune=np.linspace(0.02,0.8,120); LL,PP=np.meshgrid(load,prune)
r_eff=PP-0.38*LL+0.12/(1+LL)
Psi=np.tanh(1.6*LL/(PP+0.04))
Win=1/(1+np.exp(-12*(Psi-0.15)))*1/(1+np.exp(12*(Psi-0.82)))
Gdiag=1/(1+np.exp(-16*r_eff))*Win
arr=np.c_[LL.ravel(),PP.ravel(),Gdiag.ravel(),Psi.ravel(),r_eff.ravel()]
savecsv('phase_diagram',arr,'distinction_load,pruning_capacity,reportability_probability,Psi,effective_fold_parameter')
fig,ax=plt.subplots(figsize=(6.4,4.4))
im=ax.imshow(Gdiag,origin='lower',extent=[load.min(),load.max(),prune.min(),prune.max()],aspect='auto')
ax.contour(LL,PP,Gdiag,levels=[0.5],colors='k',linewidths=1.5)
ax.set_xlabel('distinction load $H_{task}+e$')
ax.set_ylabel('active pruning capacity $S$')
ax.set_title('Reportability phase diagram')
fig.colorbar(im,ax=ax,label='reportability probability')
savefig('fig7_phase_diagram')

# Figure 8: Landauer lower bound
bits=np.linspace(0,1e9,200) # bits
kBT=4.11e-21 # J at room temp ~300K
Q=kBT*np.log(2)*bits
metabolic=Q*1e8  # not claimed exact, display amplification scale
arr=np.c_[bits,Q,metabolic]
savecsv('landauer_bound',arr,'erased_or_reorganized_bits,landauer_lower_bound_J,illustrative_metabolic_overhead_J')
fig,ax=plt.subplots(figsize=(6.4,4.3))
ax.plot(bits/1e6,Q/1e-15,label='Landauer lower bound')
ax.plot(bits/1e6,metabolic/1e-7,ls='--',label='illustrative biological overhead')
ax.set_xlabel('pruned residual distinctions (million bits)')
ax.set_ylabel('scaled heat / energetic cost')
ax.set_title('Information-energy bridge for active pruning')
ax.legend(fontsize=9)
savefig('fig8_landauer_bridge')

# Parameter summary CSV
params = [
    ('alpha','0.15','residue deposition per overload unit','all ODE simulations'),
    ('eta_e','0.08','error-to-residue gain','overload/rescue'),
    ('d','0.02','passive decay of residue','all'),
    ('S','0.02-0.8','active pruning capacity','phase/rescue sweeps'),
    ('K','0.25','pruning half-saturation','all'),
    ('gamma_G','0.25','access coherence recovery','ODE'),
    ('beta_rho','0.1','residue damage to access','ODE/network'),
    ('C_eff','0.1-1.5','effective capacity','phase diagram'),
    ('R_min','0.25','reportability failure threshold','classification'),
    ('R_rec','0.55','rescue threshold','rescue simulations'),
    ('sigma','0.05','normal-form noise amplitude','early warning'),
    ('N','90','network nodes','network transition'),
]
with open(os.path.join(DATA,'parameter_table.csv'),'w') as f:
    f.write('parameter,baseline_or_range,meaning,usage\n')
    for row in params:
        f.write(','.join(row)+'\n')

print('Generated figures and data in', OUT)
